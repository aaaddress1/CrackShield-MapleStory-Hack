//150.2 MSCRC
void* FakeDump_adr = NULL;
int DumpEnd = 0;
int FakeDump_offset = 0;
//---------------------------------------------------------------------------
void __declspec(naked) MSCRC1(){
VMProtectBegin("MSCRC1");
__asm{
// MSCRC2
cmp edx,0x0A3377F
jl OtherCheck
cmp edx,0x0A33786
jg OtherCheck

add edx,[FakeDump_offset]
jmp MSCRC1Ret
// SendPacket: 0x04965D2
OtherCheck:
cmp edx,0x04965CF // -3
jl MSCRC1Ret
cmp edx,0X04965D6 // +4
jg MSCRC1Ret

add edx,[FakeDump_offset]

MSCRC1Ret:
//MSCRC1�쥻�ʧ@
push [edx]
push 0x11D6D3D
ret
}
VMProtectEnd();
}
//---------------------------------------------------------------------------
void __declspec(naked) MSCRC2(){
VMProtectBegin("MSCRC2");
__asm{
Cmp  Ecx, 0x00401000
Jl   Back
Cmp  Ecx, [DumpEnd]
Jg   Back

Add  Ecx, [FakeDump_offset]

Back:
Mov  Dl, [Ecx]
Add  Dl, 01
Push 0x0A33787
Ret
}
VMProtectEnd();
}
//---------------------------------------------------------------------------

void __declspec(naked) FuckHS(){
VMProtectBegin("FuckHS");
__asm{
Mov  dword ptr [0x0A059A6], 0xFD5C8D89
Mov  word ptr [0x0A059AA], 0xFFFF
Mov  Ecx, 0x0A059A6
Add  Ecx, [FakeDump_offset]
Mov  dword ptr [Ecx], 0xFD5C8D89
Mov  word ptr [Ecx+4], 0xFFFF
Sub  Ecx, Ecx
Xor  Ecx, 0x201E80
Shl  Ecx, 1
Push 0x0A059A6
Ret
}
VMProtectEnd();
}

void FuckChecking() {
try {VMProtectBegin("FuckChecking");
	MEMORY_BASIC_INFORMATION mbi;
	VirtualQueryEx(GetCurrentProcess(),(PVOID)0x00401000,&mbi,sizeof(MEMORY_BASIC_INFORMATION));
	DumpEnd = 0x00401000 + mbi.RegionSize;
	FakeDump_adr = malloc(mbi.RegionSize);
	memcpy(FakeDump_adr, (LPVOID)0x00401000, mbi.RegionSize);
	FakeDump_offset = (int)FakeDump_adr - 0x00401000;
	AsmJump(0X011DEDC9,MSCRC1, 2);
	AsmJump(0x0A33782, MSCRC2, 0);
	AsmJump(0x0A059A6, FuckHS, 1);
	EnableMultiMS();
VMProtectEnd();
} catch (...) {//ShowMessage("�}��HackShield�~���o�Ͱ��D�C");
ExitProcess(NULL);
}
}

